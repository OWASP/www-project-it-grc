# from collections import defaultdict
# from datetime import timedelta, datetime, date
# from dateutil.relativedelta import relativedelta
# import pandas as pd
# from pytz import utc
# from odoo import models, fields, api, _
# from odoo.http import request
# from odoo.tools import float_utils

from odoo import models, fields, api, _



class DashBoard_class(models.Model):
    _name = "dashboard"
    _description = "Dash Board"

    def dash(self):
        pass