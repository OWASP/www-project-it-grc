* Implement generic trigger for binding
  based on ir.export linked to the index
  (the aim is to set the binding to be updated
  if we modify a field configured in the exporter)
