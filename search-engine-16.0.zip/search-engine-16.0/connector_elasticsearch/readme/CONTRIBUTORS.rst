* Laurent Corron <laurentcorron@gmail.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Raphaël Reverdy <raphael.reverdy@akretion.com>
* Simone Orsi <simone.orsi@camptocamp.com>
* Iván Todorovich <ivan.todorovich@camptocamp.com>
