Use Exporter (ir.exports) as serializer for connector_search_engine
