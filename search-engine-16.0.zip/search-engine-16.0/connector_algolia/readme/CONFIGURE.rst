You have to configure your backend (api, secret) and index in the menu

"Connector > Search Engine Backend"
