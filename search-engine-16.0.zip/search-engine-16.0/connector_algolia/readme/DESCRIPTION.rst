Base module to synchronize Algolia search engine with Odoo.

Depends on `connector_search_engine`.
