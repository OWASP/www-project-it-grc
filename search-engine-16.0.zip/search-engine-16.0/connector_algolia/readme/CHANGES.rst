Changelog
---------

Future (?)
~~~~~~~~~~


12.0.2.0.0
~~~~~~~~~~
- the base module connector_search_engine have been updated please read the change log before updating
