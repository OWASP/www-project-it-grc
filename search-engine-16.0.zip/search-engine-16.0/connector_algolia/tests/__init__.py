from . import test_se_algolia
from . import test_se_index_settings
