Base module for connecting Odoo with external search engines. This addon is
intended to be used as a base for other addons that implement specific search
engines. It's designed to be easily extensible and modular.
